import sys
import pygame
from settings import Settings
from ship import Ship


class AlienInvasion:
    """初始化游戏并创建游戏资源"""
    def __init__(self):
        pygame.init()
        self.settings = Settings()
        self.screen = pygame.display.set_mode((self.settings.screen_width, self.settings.screen_height))
        pygame.display.set_caption("Alien Invasion")
        self.ship = Ship(self)

    def run_game(self):
        """开始游戏主循环"""
        while True:
            # 监控鼠标和键盘的操作（事件）
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()
            # 每次循环重绘屏幕
            self.screen.fill(self.settings.background_color)
            self.ship.blitme()
            # 显示最新一次绘制的游戏屏幕
            pygame.display.flip()


if __name__ == '__main__':
    # 创建游戏实例并运行游戏循环
    ai = AlienInvasion()
    ai.run_game()