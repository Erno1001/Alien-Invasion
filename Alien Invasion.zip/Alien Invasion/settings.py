class Settings:
    def __init__(self):
        self.screen_width = 1200
        self.screen_height = 800
        self.background_color = (240, 240, 235)